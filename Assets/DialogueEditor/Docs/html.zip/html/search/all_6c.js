var searchData=
[
  ['lines',['lines',['../class_dialogue_file.html#a5c3332458c70ae878422121b25d8d553',1,'DialogueFile']]],
  ['loaddialoguefile',['LoadDialogueFile',['../class_dialogue_manager.html#ab03c9a4f4e1c04fe2816759d3cbd2e11',1,'DialogueManager.LoadDialogueFile(string resourcePath)'],['../class_dialogue_manager.html#a27d395f54d60a2e573b032b61e39e3ee',1,'DialogueManager.LoadDialogueFile(DialogueFile file)']]]
];
