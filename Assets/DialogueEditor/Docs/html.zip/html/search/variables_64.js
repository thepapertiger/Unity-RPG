var searchData=
[
  ['dialogue',['dialogue',['../class_dialogue_file_1_1_dialogue_line.html#ab031ef2ab7b1eb5d8c66ef6b3ae304fa',1,'DialogueFile.DialogueLine.dialogue()'],['../class_dialogue_1_1_choice.html#a3ef9c48d0c102c3363db7c4a08efeca7',1,'Dialogue.Choice.dialogue()']]],
  ['dialogueentry',['dialogueEntry',['../class_dialogue_file_1_1_dialogue_line.html#a5d2261cc93a6e984a77a914952523a35',1,'DialogueFile::DialogueLine']]]
];
