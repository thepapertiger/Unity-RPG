var searchData=
[
  ['id',['id',['../class_dialogue_file_1_1_dialogue_line.html#aa14c4c01789dfb925cde135a4b1d89f2',1,'DialogueFile.DialogueLine.id()'],['../class_dialogue_file_1_1_dialogue_entry.html#aadebcbad64b95ac662382fefdbada06d',1,'DialogueFile.DialogueEntry.id()'],['../class_dialogue_1_1_choice.html#a0fe5b9811253ca337c051cd0d2966e97',1,'Dialogue.Choice.id()']]]
];
