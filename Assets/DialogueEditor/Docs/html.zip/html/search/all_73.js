var searchData=
[
  ['speaker',['speaker',['../class_dialogue_file_1_1_dialogue_line.html#aa59736862055a644c999191f3088a8be',1,'DialogueFile.DialogueLine.speaker()'],['../class_dialogue_1_1_choice.html#a762f63cecd9f5f1281793dcc22705593',1,'Dialogue.Choice.speaker()']]],
  ['speakers',['speakers',['../class_dialogue_file_1_1_dialogue_entry.html#a52035ab3acca5663864ab6957e3a977d',1,'DialogueFile::DialogueEntry']]],
  ['start',['Start',['../class_dialogue.html#a83bc943ea718f1994f81a4f61db8a4c2',1,'Dialogue']]]
];
