var searchData=
[
  ['userdata',['userData',['../class_dialogue_file_1_1_dialogue_line.html#afff526b24d2c4f5da809aad40020ecf1',1,'DialogueFile.DialogueLine.userData()'],['../class_dialogue_1_1_choice.html#a82c5dd06bf6676bf5c38a577c2fb44a4',1,'Dialogue.Choice.userData()']]]
];
