var searchData=
[
  ['dialogueentry',['DialogueEntry',['../class_dialogue_file_1_1_dialogue_entry.html#a22c0dddb6da67d0d6a88ea94d9d1c18b',1,'DialogueFile.DialogueEntry.DialogueEntry()'],['../class_dialogue_file_1_1_dialogue_entry.html#a129c3a46fe5bf38183cf813947312b18',1,'DialogueFile.DialogueEntry.DialogueEntry(string id)']]]
];
