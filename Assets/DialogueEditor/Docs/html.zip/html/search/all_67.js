var searchData=
[
  ['getchoices',['GetChoices',['../class_dialogue.html#a733235ae799a973578862a15767dce9b',1,'Dialogue']]],
  ['getdialogue',['GetDialogue',['../class_dialogue_manager.html#a43bccf164ea06ae1967760757cfa6805',1,'DialogueManager']]]
];
