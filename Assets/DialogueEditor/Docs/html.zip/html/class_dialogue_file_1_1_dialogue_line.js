var class_dialogue_file_1_1_dialogue_line =
[
    [ "dialogue", "class_dialogue_file_1_1_dialogue_line.html#ab031ef2ab7b1eb5d8c66ef6b3ae304fa", null ],
    [ "dialogueEntry", "class_dialogue_file_1_1_dialogue_line.html#a5d2261cc93a6e984a77a914952523a35", null ],
    [ "id", "class_dialogue_file_1_1_dialogue_line.html#aa14c4c01789dfb925cde135a4b1d89f2", null ],
    [ "output", "class_dialogue_file_1_1_dialogue_line.html#a3014c09d68c41e5b8a4fcdbfb9c35694", null ],
    [ "position", "class_dialogue_file_1_1_dialogue_line.html#a0b78c6cf3bfd4772883b5e7b27da7ad0", null ],
    [ "speaker", "class_dialogue_file_1_1_dialogue_line.html#aa59736862055a644c999191f3088a8be", null ],
    [ "userData", "class_dialogue_file_1_1_dialogue_line.html#afff526b24d2c4f5da809aad40020ecf1", null ]
];