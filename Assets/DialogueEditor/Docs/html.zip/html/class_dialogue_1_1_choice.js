var class_dialogue_1_1_choice =
[
    [ "dialogue", "class_dialogue_1_1_choice.html#a3ef9c48d0c102c3363db7c4a08efeca7", null ],
    [ "id", "class_dialogue_1_1_choice.html#a0fe5b9811253ca337c051cd0d2966e97", null ],
    [ "speaker", "class_dialogue_1_1_choice.html#a762f63cecd9f5f1281793dcc22705593", null ],
    [ "userData", "class_dialogue_1_1_choice.html#a82c5dd06bf6676bf5c38a577c2fb44a4", null ]
];