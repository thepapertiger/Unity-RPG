var class_dialogue =
[
    [ "AddLine", "class_dialogue.html#aed9fab9d027db02676382d3886247596", null ],
    [ "GetChoices", "class_dialogue.html#a733235ae799a973578862a15767dce9b", null ],
    [ "PickChoice", "class_dialogue.html#a2fcf12eaf5426c5436ba03a370423f61", null ],
    [ "Start", "class_dialogue.html#a83bc943ea718f1994f81a4f61db8a4c2", null ]
];