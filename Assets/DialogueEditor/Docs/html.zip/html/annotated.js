var annotated =
[
    [ "Dialogue.Choice", "class_dialogue_1_1_choice.html", "class_dialogue_1_1_choice" ],
    [ "Dialogue", "class_dialogue.html", "class_dialogue" ],
    [ "DialogueFile.DialogueEntry", "class_dialogue_file_1_1_dialogue_entry.html", "class_dialogue_file_1_1_dialogue_entry" ],
    [ "DialogueFile", "class_dialogue_file.html", "class_dialogue_file" ],
    [ "DialogueFile.DialogueLine", "class_dialogue_file_1_1_dialogue_line.html", "class_dialogue_file_1_1_dialogue_line" ],
    [ "DialogueManager", "class_dialogue_manager.html", "class_dialogue_manager" ]
];