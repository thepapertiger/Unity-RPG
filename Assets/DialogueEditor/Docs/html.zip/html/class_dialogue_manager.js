var class_dialogue_manager =
[
    [ "GetDialogue", "class_dialogue_manager.html#a43bccf164ea06ae1967760757cfa6805", null ],
    [ "LoadDialogueFile", "class_dialogue_manager.html#ab03c9a4f4e1c04fe2816759d3cbd2e11", null ],
    [ "LoadDialogueFile", "class_dialogue_manager.html#a27d395f54d60a2e573b032b61e39e3ee", null ]
];