var class_dialogue_file =
[
    [ "entries", "class_dialogue_file.html#a1126c8c9aa907132d8993aaec1b1588a", null ],
    [ "lines", "class_dialogue_file.html#a5c3332458c70ae878422121b25d8d553", null ]
];