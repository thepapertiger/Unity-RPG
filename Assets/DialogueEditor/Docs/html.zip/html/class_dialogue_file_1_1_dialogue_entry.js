var class_dialogue_file_1_1_dialogue_entry =
[
    [ "DialogueEntry", "class_dialogue_file_1_1_dialogue_entry.html#a22c0dddb6da67d0d6a88ea94d9d1c18b", null ],
    [ "DialogueEntry", "class_dialogue_file_1_1_dialogue_entry.html#a129c3a46fe5bf38183cf813947312b18", null ],
    [ "id", "class_dialogue_file_1_1_dialogue_entry.html#aadebcbad64b95ac662382fefdbada06d", null ],
    [ "maxLineId", "class_dialogue_file_1_1_dialogue_entry.html#ae28f83fc68ce8f95642a845460c3e18e", null ],
    [ "speakers", "class_dialogue_file_1_1_dialogue_entry.html#a52035ab3acca5663864ab6957e3a977d", null ]
];